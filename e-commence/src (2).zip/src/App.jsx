// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import './App.css'

// function App() {
//   const [products, setProducts] = useState([]);

//   useEffect(() => {
//     const fetchProducts = async () => {
//       const { data } = await axios.get('http://localhost:5000/api/products');
//       setProducts(data);
//     };

//     fetchProducts();
//   }, []);

//   return (
//     <>
//       <div className="App">
//         <h1>Product List</h1>
//         <div className="product-list">
//           {products.map(product => (
//             <div key={product._id} className="product-card">
//               <img src={product.imageUrl} alt={product.name} />
//               <h3>{product.name}</h3>
//               <p>{product.price}</p>
//             </div>
//           ))}
//       </div>
//     </div>
        
//     </>
//   )
// }

// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ProductList from './components/ProductList';
import ProductDetails from './components/ProductDetails';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<ProductList />} />
        <Route path="/product/:id" element={<ProductDetails />} />
      </Routes>
    </Router>
  );
}

export default App;



