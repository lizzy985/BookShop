// // src/components/ProductList.js
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const ProductList = () => {
//   const [products, setProducts] = useState([]);

//   useEffect(() => {
//     const fetchProducts = async () => {
//       try {
//         const { data } = await axios.get('/api/products');
//         setProducts(data);
//       } catch (error) {
//         console.error('Error fetching products', error);
//       }
//     };
//     fetchProducts();
//   }, []);

//   const deleteProduct = async (id) => {
//     if (window.confirm('Are you sure you want to delete this product?')) {
//       try {
//         await axios.delete(`/api/products/${id}`);
//         setProducts(products.filter(product => product._id !== id));  // Update UI after deletion
//       } catch (error) {
//         console.error('Error deleting product', error);
//       }
//     }
//   };

//   return (
//     <div>
//       <h1>Product List</h1>
//       <ul>
//         {products.map(product => (
//           <li key={product._id}>{product.name}</li>
//         ))}
//         <button onClick={() => deleteProduct(product._id)}>Delete</button>
//       </ul>

//     </div>
//   );
// };

// export default ProductList;


// ProductList.js
import React, { useState, useEffect } from 'react';
import ProductService from './ProductService';
import CreateProduct from './CreateProduct';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const result = await ProductService.getProducts();
      setProducts(result.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const handleCreateProduct = () => {
    setIsCreating(true);
  };

  const handleProductCreated = () => {
    setIsCreating(false);
    fetchProducts();
  };

  const handleUpdateProduct = async (id, updatedProduct) => {
    try {
      await ProductService.updateProduct(id, updatedProduct);
      fetchProducts();
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  const handleDeleteProduct = async (id) => {
    try {
      await ProductService.deleteProduct(id);
      fetchProducts();
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  return (
    <div>
      <button onClick={handleCreateProduct}>Create New Product</button>
      {isCreating && <CreateProduct onProductCreated={handleProductCreated} />}
      <ul>
        {products.map((product) => (
          <li key={product.id}>
            {product.name} - ${product.price}
            <button onClick={() => handleUpdateProduct(product.id, { name: 'Updated Name', price: 20 })}>
              Update
            </button>
            <button onClick={() => handleDeleteProduct(product.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProductList;
